
Logicor.USB "CLSID:F877BA6D-0195-4A9D-9F71-C86755A4E078"

1. Login as Administrator.

2. Save contents of this folder(HIDLibrary.dll, Logicor.USB.dll, Readme.txt, ScaleTest.vbs) to C:\Windows\Syswow64 - on Server 2008, 64 bit.
 
3. Navigate to an ADMIN command prompt

4. Change direcotry to C:\Windows\Syswow64

5. Copy and paste the following line and run it.
C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727\regasm /codebase Logicor.USB.dll

6. Integrate in the following code to dialog.asp.

7. To test scale run ScaleTest.vbs.  Should return weight back.

-- Create a Toledo USB scale type...
insert into app.scale_types (code, description, output, response_length, pounds_offset, pounds_length, ounces_offset, ounces_length, response_timeout)
values ('TUSB', 'Toledo USB', 'W', 16, 2, 2, 8, 4, 2);

function ReadScale()
{
  //   05-15-13 rps; ReadScale rework, add Toledo Scale support
  //   01-17-07 rps; ReadScale rework, add CR to VBParseString()
  var bDebug = false;
  var intWeight = 0;

  // --- something interesting: uncomment this line to see how many times ReadScale is fired - compare ENTER or TAB coming out of the LPN field...
  //alert('enter readscale');

  //   06-22-09 rps; Add ability to manually enter weight, and use the scale too.
  if(document.all.afPackage_ActualWeight.value > 0)
  {
    return;
  }

  if(document.all.SCALE_CODE.value == 'TUSB')
  {
    strOldStatus = parent.header.document.all.description.innerText;
    parent.header.document.all.description.innerText = "Reading scale...";

    /* specific Mettler Toledo values
    set oScale = CreateObject("Logicor.USB.Scale")
    oScale.VendorID = 3768  ' 0x0EB8
    oScale.ProductID = 61440 ' 0xF000 */

    //intWeight = 4.5
    document.all.TodedoScale.VendorID = 3768;
    document.all.TodedoScale.ProductID = 61440;

    intWeight = document.all.TodedoScale.ReadScale();

    if (!IsPositiveNumber(intWeight))
    {
      alert('negative return: ' + intWeight);
      document.all.afPackage_ActualWeight.value = 0.00;
    }
    else
    {
      document.all.afPackage_ActualWeight.value = intWeight;
    }
    parent.header.document.all.description.innerText = strOldStatus;
  }
  else
  {
    intRetryAttempts = 1
    while (intRetryAttempts != 0)
    {
      if(bDebug)
      {
      alert('SCALE_PORT: ' + document.all.SCALE_PORT.value + ', ' +
        'SCALE_BAUDRATE: ' + document.all.SCALE_BAUDRATE.value + ', ' +
        'SCALE_PARITY: ' + document.all.SCALE_PARITY.value + ', ' +
        'SCALE_DATABITS: ' + document.all.SCALE_DATABITS.value + ', ' +
        'SCALE_STOPBITS: ' + document.all.SCALE_STOPBITS.value + ', ' +
        'SCALE_OUTPUT (raw): ' + document.all.SCALE_OUTPUT.value + ', ' +
        'SCALE_OUTPUT (VBParseString): ' + VBParseString(document.all.SCALE_OUTPUT.value) + ', ' +
        'SCALE_RESPONSE_LENGTH: ' + document.all.SCALE_RESPONSE_LENGTH.value + ', ' +
        'SCALE_POUNDS_OFFSET: ' + document.all.SCALE_POUNDS_OFFSET.value + ', ' +
        'SCALE_POUNDS_LENGTH: ' + document.all.SCALE_POUNDS_LENGTH.value + ', ' +
        'SCALE_OUNCES_OFFSET: ' + document.all.SCALE_OUNCES_OFFSET.value + ', ' +
        'SCALE_OUNCES_LENGTH: ' + document.all.SCALE_OUNCES_LENGTH.value + ', ' +
        'SCALE_TIMEOUT: ' + document.all.SCALE_TIMEOUT.value);
      }

      strOldStatus = parent.header.document.all.description.innerText;
      parent.header.document.all.description.innerText = "Reading scale...";

      if (!bDebug)
      {
        intWeight = document.all.PfastshipEliteTools.ReadScaleEx(document.all.SCALE_PORT.value, document.all.SCALE_BAUDRATE.value, document.all.SCALE_PARITY.value, document.all.SCALE_DATABITS.value, document.all.SCALE_STOPBITS.value, 0, VBParseString(document.all.SCALE_OUTPUT.value), document.all.SCALE_RESPONSE_LENGTH.value, document.all.SCALE_POUNDS_OFFSET.value, document.all.SCALE_POUNDS_LENGTH.value, document.all.SCALE_OUNCES_OFFSET.value, document.all.SCALE_OUNCES_LENGTH.value, document.all.SCALE_TIMEOUT.value);
      }

      if(bDebug)
      {
        intWeight = 3.85;
        alert(intWeight);
        bDebug = false;
      }
      if (!IsPositiveNumber(intWeight))
      {
        //document.all.afPackage_ActualWeight.value = 1;
        //parent.header.document.all.description.innerText = strOldStatus;

        // --- 090616 rps; debug effort...
        intRetryAttempts = intRetryAttempts - 1;
        alert('negative return: ' + intWeight);
      }
      else
      {
        document.all.afPackage_ActualWeight.value = intWeight;
        parent.header.document.all.description.innerText = strOldStatus;
        break;
      }

      parent.header.document.all.description.innerText = strOldStatus;
    }
  }
}

-- search for <OBJECT ID="PfastshipEliteTools", insert block after it:

<OBJECT ID="TodedoScale"
CLASSID="CLSID:F877BA6D-0195-4A9D-9F71-C86755A4E078"
CODEBASE="Logicor.USB.dll">
</OBJECT>

-- set up scale type in Worstations, and mode, log out.
