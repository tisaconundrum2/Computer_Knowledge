-------------------------------------------------------------------------
Log Entry Wednesday, September 19, 2012 3:27 PM

Installation
---------------
- In IE9 32, in addition to the normal enabling of Trusted Sites, and ActiveX controls, go to Options, Advanced tab, uncheck "Enable memory protection to help mitigate online attacks".
- Create "C:\Program Files (x86)\Logicor\"
- copy down the deliverable zip file, unzip to "C:\Program Files (x86)\Logicor\", and unzip it to there.
- run a admin cmd window, copy and paste the following into it (run it line by line first)

c:
cd c:\windows\syswow64
Regsvr32 /u /s c:\windows\syswow64\PfastshipElite.dll
Regsvr32 /u /s c:\windows\system32\PfastshipElite.dll
del c:\windows\syswow64\PfastshipElite.dll
del c:\windows\system32\PfastshipElite.dll
copy "C:\Program Files (x86)\Logicor\PfastshipElite.dll" c:\windows\syswow64
copy "C:\Program Files (x86)\Logicor\GlobalshipScaleProcess.exe" c:\windows\syswow64
copy "C:\Program Files (x86)\Logicor\GlobalshipScaleProcess.ini" c:\windows\syswow64
copy "C:\Program Files (x86)\Logicor\scomm32.ocx" c:\windows\syswow64
Regsvr32 /s c:\windows\syswow64\scomm32.ocx
Regsvr32 /s c:\windows\syswow64\PfastshipElite.dll

INI File 
----------
[settings]
init=file,3,9600,E,7,1,0,W,8,2,7,0,0,2,
initcr=yes
writetolog=yes
exceptionoption=1
; 1=return the partial string, 2=fire off another init, until we get what we want, try 2 times, 3=bail, and wait for timeout, to see if this on_comm fires again with more received data

Notes:
-------
- init: filename, intPort As Integer, intBaud As Integer, chrParity As String, intDataBits As Integer, intStopBits As Integer, intHandshaking As Integer, strInit As String, intResponseLength As Integer, intPoundsOffset As Integer, intPoundsLength As Integer, intOuncesOffset As Integer, intOuncesLength As Integer, intTimeout As Integer, xml As String
- initcr: if "yes", will send a CR after the init string.  Some scales require this, according to the codebase provided, this was not being sent.
- writetolog:  If "yes", will write to PfastshipElite.log in the Windows Temp Directory. 
- exceptionoption:  How to handle this situation where we got something, but the length of it is not our minumum required.  Something to tweak, when running out of ideas.
   - if Data length is less than expected, we can handle it in different ways: 1=wait for more chars to flow into buffer, until timeout, try 1 time total.  2=close the port and fire off another init, try 4 times total, 3=immediately bail with a -1, in order to trigger a re-weigh, called from PfastshipElite.dll.  Try 2 times total. 4=same as 3, but try 3 times total.  5=same as 3, but try 4 times total.


Copy/Paste Strings
----------------------
rem Del c:\windows\syswow64\scomm32.ocx
Del c:\windows\syswow64\PfastshipElite.dll
Del c:\windows\syswow64\GlobalshipScaleProcess.exe
Copy "C:\Program Files (x86)\Logicor\GlobalshipScaleProcess.exe" c:\windows\syswow64
Copy "C:\Program Files (x86)\Logicor\GlobalshipScaleProcess.ini" c:\windows\syswow64
Copy scomm32.ocx c:\windows\syswow64
Copy "C:\Program Files (x86)\Logicor\PfastshipElite.dll" c:\windows\syswow64
notepad c:\windows\syswow64\GlobalshipScaleProcess.ini
c:
cd c:\windows\syswow64
Regsvr32 c:\windows\syswow64\scomm32.ocx
Regsvr32 c:\windows\syswow64\PfastshipElite.dll


-------------------------------------------------------------------------
Log Entry Friday, September 14, 2012 12:42 PM

' c:
' cd c:\windows\syswow64
' wscript.exe "C:\Program Files (x86)\Logicor\testscript.vbs"

dim oPFS 
set oPFS = CreateObject("PfastshipElite.Tools")
if isobject(oPFS) then 
  msgbox oPFS.ReadScaleEx(3, 9600, "E", 7, 1, 0, "W", 9, 2, 7, 0, 0, 2)
else
  msgbox "no object"
end if

set oPFS = nothing